# The Answer Package

This is a simple example package. 
Github Markdown reference:
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)


This package provides a most basic setup example of an installable package.  As a bonus it also provides the answer to Life, the Universe and Everything.

Installing the Answer package

You can use pip to install from TestPyPI:

Either:

1.) cd to your working directory
2.) python3 -m pip install --index-url https://test.pypi.org/simple/ answer_pkg_ex


You can test that it was installed correctly by importing the module and referencing the name property.

Run the Python interpreter (make sure you are still in your virtualenv if you are using one):

>>> python

And then import the module and print out the name property.

>>> import answer_pkg
>>> answer_pkg.name
'answer_pkg'